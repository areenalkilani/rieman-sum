#include <iostream>Add commentMore actions
#include <chrono>

using namespace std;
using namespace std::chrono;

double f(double x) {
    return 4.0 / (1.0 + x * x);  
}

int main() {
    const long long num_steps = 100000000;
    double step = 1.0 / num_steps;
    double sum = 0.0;

    auto start = high_resolution_clock::now();

    for (long long i = 0; i < num_steps; ++i) {
        double x = (i + 0.5) * step;
        sum += f(x);
    }

    double pi = step * sum;

    auto end = high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(end - start);

    cout << "Estimated Pi (Sequential): " << pi << endl;
    cout << "Execution Time: " << duration.count() << " ms" << endl;

    return 0;
}
Add comment