// parallel.cpp
#include <iostream>
#include <pthread.h>
#include <chrono>

using namespace std;
using namespace std::chrono;

const long long num_steps = 100000000;
int num_threads;
double step = 1.0 / num_steps;
double *partial_sums;

void* compute_partial_sum(void* arg) {
    int id = *(int*)arg;
    long long chunk_size = num_steps / num_threads;
    long long start = id * chunk_size;
    long long end = (id == num_threads - 1) ? num_steps : start + chunk_size;

    double sum = 0.0;
    for (long long i = start; i < end; ++i) {
        double x = (i + 0.5) * step;
        sum += 4.0 / (1.0 + x * x);
    }

    partial_sums[id] = sum;
    pthread_exit(0);
}

int main() {
    cout << "Enter number of threads: ";
    cin >> num_threads;

    pthread_t threads[num_threads];
    int thread_ids[num_threads];
    partial_sums = new double[num_threads];

    auto start = high_resolution_clock::now();

    for (int i = 0; i < num_threads; ++i) {
        thread_ids[i] = i;
        pthread_create(&threads[i], NULL, compute_partial_sum, &thread_ids[i]);
    }

    for (int i = 0; i < num_threads; ++i) {
        pthread_join(threads[i], NULL);
    }

    double total_sum = 0.0;
    for (int i = 0; i < num_threads; ++i) {
        total_sum += partial_sums[i];
    }

    double pi = step * total_sum;

    auto end = high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(end - start);

    cout << "Estimated Pi (Parallel): " << pi << endl;
    cout << "Execution Time: " << duration.count() << " ms" << endl;

    delete[] partial_sums;

    return 0;
}
